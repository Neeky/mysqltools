#ifndef TYPES_H
#define TYPES_H

#include <stdint.h>
#include <stdlib.h>

typedef uint32_t uint32;
typedef uint64_t uint64;

#endif
