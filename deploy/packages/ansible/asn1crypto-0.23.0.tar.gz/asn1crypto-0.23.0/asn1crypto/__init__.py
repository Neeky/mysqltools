# coding: utf-8
from __future__ import unicode_literals, division, absolute_import, print_function

from .version import __version__, __version_info__

__all__ = [
    '__version__',
    '__version_info__',
]
