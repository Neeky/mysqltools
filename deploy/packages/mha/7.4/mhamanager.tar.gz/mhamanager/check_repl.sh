#!/bin/bash

masterha_check_repl --conf=/etc/masterha/app.cnf
