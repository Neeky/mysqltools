#!/bin/bash

#001 goto workdir
sd=$(dirname $0)
cd $sd

#002 install dependents
cd manager-dependents
yum -y localinstall ./*
cd ..

#003 install mha manager
cd mha4mysql-manager-master
perl Makefile.PL && make && make install

