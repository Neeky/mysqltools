#!/bin/bash

ldconfig

# 001 go to workdir
sd=$(dirname $0)
cd $sd

cd nodes-dependents
yum -y localinstall *
cd ../

# 002 install dbi
cd DBI-1.641
perl Makefile.PL && make && make install
cd ..

cd DBD-mysql-4.046
perl Makefile.PL --with-mysql=/usr/local/mysql --mysql_config=/usr/local/mysql/bin/mysql_config && make && make install
cd ..

# 003 install mha-node
cd mha4mysql-node-master
perl Makefile.PL && make && make install
