#!/bin/bash

masterha_check_status --conf=/etc/masterha/app.cnf
