#!/usr/bin/perl

use strict;
use warnings;
use DBI;

#Connect to the database.

my $dbh = DBI->connect("DBI:mysql:database=mysql;host=127.0.0.1",
                         "mha", "12345678",
                                                {'RaiseError' => 1});
my $sth = $dbh->prepare("SELECT 1 as value");
$sth->execute();
my $result = $sth->fetchrow_hashref();
print "----ok----  $result->{value}\n";
$sth->finish();
$dbh->disconnect();
