#!/bin/bash

# 001 install dependence
sd=$(dirname $0)
cd $sd

cd dependence
yum -y install gcc gcc-c++

yum -y localinstall *


# 002 install dbd-mysql
cd ../DBD-mysql-4.043
perl Makefile.PL --with-mysql=/usr/local/mysql --mysql_config=/usr/local/mysql/bin/mysql_config && make && make install


# 003 install node
cd ../mha4mysql-node-master
perl Makefile.PL && make && make install

