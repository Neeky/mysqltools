==========================
MySQL Connector/Python X.Y
==========================

MySQL Connector/Python
Copyright (c) 2011, 2016, Oracle and/or its affiliates. All rights reserved.

License information can be found in the LICENSE.txt file.


Documentation
=============

Documentation for all Connector/Python versions can be found online here:

 http://dev.mysql.com/doc/connector-python/en/index.html


License
=======

This is a release of MySQL Connector/Python, Oracle's dual-
license Python Driver for MySQL. For the avoidance of
doubt, this particular copy of the software is released
under a commercial license and the GNU General Public
License does not apply. MySQL Connector/Python is brought
to you by Oracle.

Copyright (c) 2011, 2016, Oracle and/or its affiliates. All rights reserved.

This distribution may include materials developed by third
parties. For license and attribution notices for these
materials, please refer to the documentation that accompanies
this distribution (see the "Licenses for Third-Party Components"
appendix) or view the online documentation at 
<http://dev.mysql.com/doc/>


