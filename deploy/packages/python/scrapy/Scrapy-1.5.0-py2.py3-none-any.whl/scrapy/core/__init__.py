"""
Scrapy core library classes and functions.
"""
