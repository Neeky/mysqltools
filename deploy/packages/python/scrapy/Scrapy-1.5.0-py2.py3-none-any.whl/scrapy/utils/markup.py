"""
Transitional module for moving to the w3lib library.

For new code, always import from w3lib.html instead of this module
"""

from w3lib.html import *
