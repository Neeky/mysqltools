/*
 * alertmanager.h
 *
 *  Created on: Mar 8, 2017
 *      Author: wiper
 */

#ifndef ZABBIX_ALERT_MANAGER_H
#define ZABBIX_ALERT_MANAGER_H

ZBX_THREAD_ENTRY(alert_manager_thread, args);

#endif
