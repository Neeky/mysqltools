

class BenchmarkError(Exception):
    pass

