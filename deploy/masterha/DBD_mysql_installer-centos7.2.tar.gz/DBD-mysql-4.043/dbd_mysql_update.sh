#!/bin/bash


cd DBD-mysql-4.043

perl Makefile.PL --with-mysql=/usr/local/mysql --mysql_config=/usr/local/mysql/bin/mysql_config
make && make install
