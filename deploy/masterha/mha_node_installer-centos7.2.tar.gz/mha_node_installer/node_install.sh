#!/bin/bash

# 001 install dependence

sd=$(dirname $0)
cd $sd

cd dependence
yum localinstall *


# 002 install node
cd ../mha4mysql-node-master
perl Makefile.PL && make && make install

#if [ $? == 0 ]
#	make && make install
#fi
