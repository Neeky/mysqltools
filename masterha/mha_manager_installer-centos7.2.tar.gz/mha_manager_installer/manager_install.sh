#!/bin/bash

#001 install dependence
sd=$(dirname $0)
cd $sd

cd dependence
yum -y localinstall *

#002 install manager
cd ../mha4mysql-manager-master
perl Makefile.PL && make && make install

#003 create directory
mkdir -p /var/log/masterha/
