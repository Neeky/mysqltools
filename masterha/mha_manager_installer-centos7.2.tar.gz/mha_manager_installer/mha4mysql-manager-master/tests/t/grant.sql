grant all privileges on *.* to '"\'!=#&;`=|*?$\\' identified by 'pass"\'!#&;`|*?~<>^()[]{}$\\, "\'!#&;`|*?~=<>^()[]{}$\\, \\';
