#!/bin/bash

masterha_check_ssh --conf=/etc/masterha/app.cnf 
